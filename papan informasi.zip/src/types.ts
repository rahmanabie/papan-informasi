export interface Settings {
  institutionName: string;
  footerText: string;
  bgColor: string;
  textColor: string;
}
